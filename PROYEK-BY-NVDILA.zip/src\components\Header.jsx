import React from 'react';
import { Plus, Bell, Calendar, Store, UserCheck, ShieldAlert } from 'lucide-react';

export default function Header({
  title,
  subtitle,
  onOpenAddCustomer,
  onOpenAddProduct,
  onOpenAddOrder,
  onOpenAddFollowUp,
  onSwitchToCustomer,
  user,
}) {
  const todayFormatted = new Date().toLocaleDateString('id-ID', {
    weekday: 'long',
    day: 'numeric',
    month: 'long',
    year: 'numeric',
  });

  return (
    <header className="sticky top-0 z-20 bg-nvdila-bg/80 backdrop-blur-md border-b border-nvdila-warm/80 px-6 py-4">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="font-serif text-2xl font-semibold text-nvdila-charcoal">
              {title}
            </h2>
            <span className="text-xs px-2 py-0.5 rounded-full bg-nvdila-cream border border-nvdila-warm text-nvdila-darkMocha font-medium">
              by.Nvdila CRM
            </span>
          </div>
          {subtitle && (
            <p className="text-xs text-stone-500 mt-0.5">{subtitle}</p>
          )}
        </div>

        <div className="flex items-center flex-wrap gap-2.5">
          {/* Date Indicator */}
          <div className="hidden lg:flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white border border-nvdila-warm/80 text-xs text-stone-600 shadow-2xs">
            <Calendar className="w-3.5 h-3.5 text-nvdila-mocha" />
            <span>{todayFormatted}</span>
          </div>

          {/* Marketplace Sync Indicator */}
          <div className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white border border-nvdila-warm/80 text-xs text-stone-600 shadow-2xs">
            <Store className="w-3.5 h-3.5 text-emerald-600" />
            <span className="font-medium text-stone-700">Marketplace:</span>
            <span className="text-emerald-700 font-medium">Aktif Terhubung</span>
          </div>

          {/* Quick Actions Dropdown / Buttons */}
          <div className="flex items-center gap-2">
            {onOpenAddCustomer && (
              <button
                type="button"
                onClick={onOpenAddCustomer}
                className="inline-flex items-center gap-1 px-3 py-1.5 rounded-xl bg-white border border-nvdila-sand hover:bg-nvdila-cream text-nvdila-charcoal text-xs font-medium transition shadow-2xs"
                title="Tambah Pelanggan Baru"
              >
                <Plus className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">+ Pelanggan</span>
              </button>
            )}

            {onOpenAddProduct && (
              <button
                type="button"
                onClick={onOpenAddProduct}
                className="inline-flex items-center gap-1 px-3 py-1.5 rounded-xl bg-white border border-nvdila-sand hover:bg-nvdila-cream text-nvdila-charcoal text-xs font-medium transition shadow-2xs"
                title="Tambah Produk Baru"
              >
                <Plus className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">+ Produk</span>
              </button>
            )}

            {onOpenAddOrder && (
              <button
                type="button"
                onClick={onOpenAddOrder}
                className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-nvdila-charcoal hover:bg-nvdila-darkMocha text-white text-xs font-medium transition shadow-sm"
                title="Buat Pesanan Baru"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>+ Pesanan</span>
              </button>
            )}

            {onSwitchToCustomer && (
              <button
                type="button"
                onClick={onSwitchToCustomer}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-amber-50 border border-amber-200 text-amber-900 hover:bg-amber-100 text-xs font-medium transition shadow-2xs"
                title="Uji Tampilan Role Pelanggan"
              >
                <UserCheck className="w-3.5 h-3.5 text-amber-700" />
                <span className="hidden md:inline">Tampilan Pelanggan</span>
              </button>
            )}
          </div>
        </div>
      </div>
    </header>
  );
}
