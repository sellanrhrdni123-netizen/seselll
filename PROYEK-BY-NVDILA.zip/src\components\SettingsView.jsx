import React, { useState } from 'react';
import {
  Settings,
  Database,
  RotateCcw,
  Sparkles,
  Download,
  Upload,
  CheckCircle,
  AlertTriangle,
  Store,
  ShieldCheck,
  Tag,
} from 'lucide-react';

export default function SettingsView({
  onLoadSampleData,
  onResetToEmpty,
  onExportJSON,
  onImportJSON,
}) {
  const [successMsg, setSuccessMsg] = useState('');
  const [showResetConfirm, setShowResetConfirm] = useState(false);
  const [showSampleConfirm, setShowSampleConfirm] = useState(false);

  const showNotification = (msg) => {
    setSuccessMsg(msg);
    setTimeout(() => setSuccessMsg(''), 4000);
  };

  const handleFileImport = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const json = JSON.parse(event.target?.result);
        onImportJSON(json);
        showNotification('Data backup berhasil diimpor ke sistem!');
      } catch (err) {
        alert('File JSON tidak valid.');
      }
    };
    reader.readAsText(file);
  };

  return (
    <div className="space-y-6 max-w-4xl">
      {/* Top Header */}
      <div>
        <h2 className="font-serif text-xl font-bold text-nvdila-charcoal">
          Pengaturan Sistem & Manajemen Data
        </h2>
        <p className="text-xs text-stone-500">
          Kelola profil brand, saluran marketplace, serta pemuatan data uji & reset empty state
        </p>
      </div>

      {successMsg && (
        <div className="p-3.5 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-medium flex items-center gap-2">
          <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>{successMsg}</span>
        </div>
      )}

      {/* Brand Profile Card */}
      <div className="bg-white rounded-2xl border border-nvdila-warm/80 p-6 shadow-2xs space-y-4">
        <div className="flex items-center gap-3 border-b border-stone-100 pb-3">
          <div className="w-10 h-10 rounded-xl bg-nvdila-cream border border-nvdila-warm flex items-center justify-center font-serif font-bold text-nvdila-charcoal text-lg">
            N
          </div>
          <div>
            <h3 className="font-serif text-base font-semibold text-nvdila-charcoal">
              Profil Brand by.Nvdila
            </h3>
            <p className="text-xs text-stone-500">
              Identitas sistem Customer Relationship Management khusus hijab
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
          <div>
            <span className="text-stone-400 block mb-1">Nama Brand</span>
            <input
              type="text"
              readOnly
              value="by.Nvdila"
              className="w-full px-3 py-2 rounded-xl border border-stone-200 bg-stone-50 font-semibold text-stone-800"
            />
          </div>

          <div>
            <span className="text-stone-400 block mb-1">Kategori Usaha</span>
            <input
              type="text"
              readOnly
              value="Hijab, Pashmina & Modest Fashion"
              className="w-full px-3 py-2 rounded-xl border border-stone-200 bg-stone-50 text-stone-800"
            />
          </div>

          <div className="sm:col-span-2">
            <span className="text-stone-400 block mb-1">Fokus Operasional</span>
            <p className="p-3 rounded-xl bg-stone-50 border border-stone-200 text-stone-600 leading-relaxed">
              by.Nvdila menggunakan marketplace (Shopee, TikTok Shop, Tokopedia) dan WhatsApp sebagai kanal penjualan. Sistem CRM ini beroperasi sebagai sistem internal untuk mengkonsolidasikan data pelanggan, riwayat belanja, kalkulasi segmentasi loyalitas, dan otomasi follow-up.
            </p>
          </div>
        </div>
      </div>

      {/* Marketplace Status Indicator */}
      <div className="bg-white rounded-2xl border border-nvdila-warm/80 p-6 shadow-2xs space-y-4">
        <h3 className="font-serif text-base font-semibold text-nvdila-charcoal border-b border-stone-100 pb-2 flex items-center gap-2">
          <Store className="w-4 h-4 text-nvdila-mocha" />
          Integrasi Saluran Penjualan
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div className="p-3.5 rounded-xl border border-stone-200 bg-stone-50/60 flex items-center justify-between">
            <div>
              <p className="font-semibold text-xs text-stone-800">Shopee Indonesia</p>
              <span className="text-[10px] text-emerald-700 font-medium">Terhubung Aktif</span>
            </div>
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500"></span>
          </div>

          <div className="p-3.5 rounded-xl border border-stone-200 bg-stone-50/60 flex items-center justify-between">
            <div>
              <p className="font-semibold text-xs text-stone-800">TikTok Shop</p>
              <span className="text-[10px] text-emerald-700 font-medium">Terhubung Aktif</span>
            </div>
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500"></span>
          </div>

          <div className="p-3.5 rounded-xl border border-stone-200 bg-stone-50/60 flex items-center justify-between">
            <div>
              <p className="font-semibold text-xs text-stone-800">Tokopedia</p>
              <span className="text-[10px] text-emerald-700 font-medium">Terhubung Aktif</span>
            </div>
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500"></span>
          </div>
        </div>
      </div>

      {/* CRITICAL DATA MANAGEMENT (Empty State vs Test Data) */}
      <div className="bg-white rounded-2xl border border-amber-200 p-6 shadow-2xs space-y-4">
        <div className="flex items-center gap-2.5 border-b border-amber-100 pb-3">
          <div className="w-8 h-8 rounded-lg bg-amber-50 text-amber-800 flex items-center justify-center">
            <Database className="w-4 h-4" />
          </div>
          <div>
            <h3 className="font-serif text-base font-semibold text-stone-900">
              Manajemen Data Uji & Evaluasi (Reviewer Tool)
            </h3>
            <p className="text-xs text-stone-500">
              Sesuai persyaratan, aplikasi dimulai dalam kondisi 100% Empty State (Data Kosong). Anda dapat memuat data uji untuk mengevaluasi kalkulasi kapan saja.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-1">
          {/* Load Sample Data Button */}
          <div className="p-4 rounded-xl border border-stone-200 bg-stone-50/80 flex flex-col justify-between">
            <div>
              <div className="flex items-center gap-2 mb-1.5">
                <Sparkles className="w-4 h-4 text-amber-600" />
                <h4 className="font-semibold text-xs text-stone-800">
                  Muat Data Sampel Uji
                </h4>
              </div>
              <p className="text-xs text-stone-600 leading-relaxed mb-4">
                Mengisi database lokal dengan produk hijab asli by.Nvdila (Pashmina Viscose Modal, Hijab Instan/Tali, Bergo Instan Praktis, Inner/Ciput), spesifikasi bahan lembut flowy & jahitan double stitch rapi, data pelanggan, pesanan, dan follow-up.
              </p>
            </div>
            <button
              type="button"
              onClick={() => setShowSampleConfirm(true)}
              className="w-full py-2.5 px-4 rounded-xl bg-amber-600 hover:bg-amber-700 text-white text-xs font-semibold transition shadow-xs flex items-center justify-center gap-2"
            >
              <Sparkles className="w-4 h-4" />
              <span>Muat Data Sampel Uji</span>
            </button>
          </div>

          {/* Reset to Empty State Button */}
          <div className="p-4 rounded-xl border border-rose-200 bg-rose-50/50 flex flex-col justify-between">
            <div>
              <div className="flex items-center gap-2 mb-1.5">
                <RotateCcw className="w-4 h-4 text-rose-600" />
                <h4 className="font-semibold text-xs text-stone-800">
                  Reset ke Data Kosong (Empty State)
                </h4>
              </div>
              <p className="text-xs text-stone-600 leading-relaxed mb-4">
                Mengosongkan seluruh database (pelanggan, pesanan, produk, follow-up) kembali ke kondisi 100% murni tanpa data untuk verifikasi tampilan empty state.
              </p>
            </div>
            <button
              type="button"
              onClick={() => setShowResetConfirm(true)}
              className="w-full py-2.5 px-4 rounded-xl bg-white border border-rose-300 text-rose-700 hover:bg-rose-100 text-xs font-semibold transition shadow-2xs flex items-center justify-center gap-2"
            >
              <RotateCcw className="w-4 h-4" />
              <span>Reset ke Empty State</span>
            </button>
          </div>
        </div>

        {/* JSON Backup & Restore */}
        <div className="pt-4 border-t border-stone-100 flex flex-wrap items-center justify-between gap-3 text-xs">
          <span className="text-stone-500 font-medium">Backup & Restore File Database:</span>
          <div className="flex items-center gap-2">
            <button
              onClick={onExportJSON}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-stone-300 hover:bg-stone-50 text-stone-700 font-medium transition"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Ekspor JSON</span>
            </button>
            <label className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-stone-300 hover:bg-stone-50 text-stone-700 font-medium cursor-pointer transition">
              <Upload className="w-3.5 h-3.5" />
              <span>Impor JSON</span>
              <input type="file" accept=".json" onChange={handleFileImport} className="hidden" />
            </label>
          </div>
        </div>
      </div>

      {/* Confirmation Modals */}
      {showSampleConfirm && (
        <div className="fixed inset-0 z-50 bg-stone-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white max-w-md w-full rounded-2xl p-6 shadow-2xl border border-amber-200">
            <h3 className="font-serif text-lg font-bold text-stone-900 mb-2">
              Muat Data Sampel Uji?
            </h3>
            <p className="text-xs text-stone-600 mb-6 leading-relaxed">
              Tindakan ini akan memuat 6 produk hijab by.Nvdila, 5 pelanggan realistis, 4 pesanan marketplace, dan riwayat follow-up ke dalam browser Anda untuk keperluan demonstrasi dan verifikasi kalkulasi.
            </p>
            <div className="flex justify-end gap-2">
              <button
                onClick={() => setShowSampleConfirm(false)}
                className="px-4 py-2 rounded-xl text-stone-600 hover:bg-stone-100 text-xs font-medium"
              >
                Batal
              </button>
              <button
                onClick={() => {
                  onLoadSampleData();
                  setShowSampleConfirm(false);
                  showNotification('Data sampel uji hijab by.Nvdila berhasil dimuat!');
                }}
                className="px-4 py-2 rounded-xl bg-amber-600 text-white hover:bg-amber-700 text-xs font-semibold shadow-xs"
              >
                Ya, Muat Data Uji
              </button>
            </div>
          </div>
        </div>
      )}

      {showResetConfirm && (
        <div className="fixed inset-0 z-50 bg-stone-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white max-w-md w-full rounded-2xl p-6 shadow-2xl border border-rose-200">
            <h3 className="font-serif text-lg font-bold text-rose-900 mb-2">
              Reset ke Data Kosong (Empty State)?
            </h3>
            <p className="text-xs text-stone-600 mb-6 leading-relaxed">
              Seluruh pelanggan, pesanan, produk, follow-up, dan log aktivitas akan dihapus dari localStorage browser. Sistem akan kembali ke kondisi 100% murni tanpa data.
            </p>
            <div className="flex justify-end gap-2">
              <button
                onClick={() => setShowResetConfirm(false)}
                className="px-4 py-2 rounded-xl text-stone-600 hover:bg-stone-100 text-xs font-medium"
              >
                Batal
              </button>
              <button
                onClick={() => {
                  onResetToEmpty();
                  setShowResetConfirm(false);
                  showNotification('Database telah dikosongkan ke kondisi Empty State!');
                }}
                className="px-4 py-2 rounded-xl bg-rose-600 text-white hover:bg-rose-700 text-xs font-semibold shadow-xs"
              >
                Ya, Kosongkan Semua
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
